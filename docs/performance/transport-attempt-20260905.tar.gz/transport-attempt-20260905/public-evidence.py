"""Package or audit the explicit public transport benchmark evidence set."""

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import tarfile
import tempfile


BASE = "5e19e44a6ea0d9e6a084129ebfe2075e4881ae00"
CANDIDATE = "0ffd222f3bdbbfb81abe76ba1ce92e18a756220d"
PREFIX = "transport-attempt-20260905/"
ORIGINALS = (
    "README.md", "candidate.patch", "candidate-committed.patch",
    "send_legacy_benchmark_test.go.txt", "pre-run-SHA256SUMS", "go-env.json",
    "lscpu.json", "kernel.txt", "candidate-buildinfo.txt", "candidate-commit.txt",
    "remote-ref.txt", "baseline.log", "candidate-legacy.log", "candidate-attempt.log",
    "compare.py", "comparison.json", "timing-start.txt", "timing-end.txt", "vet.log",
)
ADDITIONS = ("PUBLIC_README.md", "public-evidence.py")
GENERATED = ("PUBLIC_FILES.txt", "source-verification.json", "PUBLIC_SHA256SUMS")
FILES = tuple(sorted(ORIGINALS + ADDITIONS + GENERATED))
PRERUN = {
    "candidate.patch": "957b2c37ea2d464e77f841203afd84763cd9be56dd26432c64fcf1a60eed191b",
    "send_legacy_benchmark_test.go.txt": "12174cf15cce5f779bee5320b7e929a0cface596a86f65d3ba91137a4286a336",
    "baseline.test": "3657ada5f86e9d488a38fbb3ecdeff2c064e669e2f5c0e3ffe313617884fc818",
    "candidate.test": "edf12d44d841a22e89507a5f7f173d33e0556fffd0985c3fd28e584f93bd1d30",
}
ATTEMPT_FIXTURE_HASH = "24ed51b1fccef5179f293d2b5d2a3f1725343dae4fd46b69a954e8fad840d8eb"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def checksums(data):
    result = {}
    for line in data.decode("ascii").splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  ([A-Za-z0-9_.-]+)", line)
        require(match is not None, "invalid checksum line")
        value, name = match.groups()
        require(name not in result, "duplicate checksum entry")
        result[name] = value
    return result


def git(repo, *args, data=None, env=None):
    return subprocess.check_output(
        ["git", "-C", str(repo), *args], input=data, env=env,
    )


def verify_source(data, repo):
    require(data["candidate-commit.txt"].decode().strip() == CANDIDATE, "candidate SHA")
    require(data["remote-ref.txt"].decode().split() ==
            [CANDIDATE, "refs/heads/feat/22-transport-attempt-time"], "recorded remote ref")
    require(checksums(data["pre-run-SHA256SUMS"]) == PRERUN, "pre-run metadata")
    for name in ("candidate.patch", "send_legacy_benchmark_test.go.txt"):
        require(digest(data[name]) == PRERUN[name], "pre-run hash: " + name)
    patch = git(repo, "diff", "--binary", BASE, CANDIDATE)
    require(patch == data["candidate.patch"] == data["candidate-committed.patch"],
            "committed patch differs from measured source snapshot")
    fixture = git(repo, "show", CANDIDATE + ":internal/transport/send_legacy_benchmark_test.go")
    require(fixture == data["send_legacy_benchmark_test.go.txt"], "shared fixture mismatch")
    attempted = git(repo, "show", CANDIDATE + ":internal/transport/send_attempt_benchmark_test.go")
    require(digest(attempted) == ATTEMPT_FIXTURE_HASH, "timestamp fixture mismatch")
    # An isolated index reconstructs the tree without changing any worktree.
    with tempfile.TemporaryDirectory(prefix="mpudp-attempt-audit-") as temporary:
        env = dict(os.environ, GIT_INDEX_FILE=str(Path(temporary) / "index"))
        git(repo, "read-tree", BASE, env=env)
        git(repo, "apply", "--cached", "--binary", "-", data=patch, env=env)
        reconstructed = git(repo, "write-tree", env=env).decode().strip()
    expected = git(repo, "rev-parse", CANDIDATE + "^{tree}").decode().strip()
    require(reconstructed == expected, "candidate tree reconstruction mismatch")
    return {
        "baseline_commit": BASE, "candidate_commit": CANDIDATE,
        "candidate_tree": expected, "reconstructed_tree": reconstructed,
        "candidate_patch_sha256": digest(patch), "legacy_fixture_sha256": digest(fixture),
        "attempt_fixture_sha256": digest(attempted),
        "excluded_baseline_binary_sha256": PRERUN["baseline.test"],
        "excluded_candidate_binary_sha256": PRERUN["candidate.test"],
    }


def verify_samples(data):
    expected_names = {
        path + "/diagnostics-" + mode
        for path in ("carrier", "captured-carrier", "listener") for mode in ("off", "on")
    }
    parsed = {}
    for label, filename, benchmark in (
        ("baseline_send", "baseline.log", "BenchmarkTransportSendLegacy"),
        ("candidate_send", "candidate-legacy.log", "BenchmarkTransportSendLegacy"),
        ("candidate_send_with_attempt", "candidate-attempt.log", "BenchmarkTransportSendAttempt"),
    ):
        lines = data[filename].decode().splitlines()
        require(lines[-1] == "PASS", "missing PASS in " + filename)
        cases = {}
        for line in lines:
            if not line.startswith("Benchmark"):
                continue
            fields = line.split()
            require(len(fields) == 10 and fields[3::2] ==
                    ["ns/op", "MB/s", "B/op", "allocs/op"], "benchmark units")
            prefix, name = fields[0].split("/", 1)
            require(prefix == benchmark and name in expected_names, "benchmark name")
            row = {"iterations": int(fields[1]), "ns_per_op": float(fields[2]),
                   "bytes_per_op": int(fields[6]), "allocs_per_op": int(fields[8])}
            require(row["iterations"] > 0 and row["ns_per_op"] > 0, "nonpositive sample")
            require(row["bytes_per_op"] == 264 and row["allocs_per_op"] == 4, "allocation result")
            cases.setdefault(name, []).append(row)
        require(set(cases) == expected_names and all(len(rows) == 5 for rows in cases.values()),
                "six cases and five samples required in " + filename)
        parsed[label] = {}
        for name, rows in cases.items():
            values = [row["ns_per_op"] for row in rows]
            parsed[label][name] = {
                "samples": rows, "median_ns_per_op": statistics.median(values),
                "min_ns_per_op": min(values), "max_ns_per_op": max(values),
                "bytes_per_op_values": [264], "allocs_per_op_values": [4],
            }
    require(parsed == json.loads(data["comparison.json"]), "comparison differs from raw samples")
    return 90


def verify_text(data):
    markers = (
        rb"-----BEGIN [A-Z ]*PRIVATE KEY-----",
        rb"(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})",
        rb"AKIA[A-Z0-9]{16}",
        rb"(?im)^\s*(?:password|token|private_key|secret_key)\s*[:=]\s*[\"']?[A-Za-z0-9+/=_-]{16,}",
    )
    for name, content in data.items():
        content.decode("utf-8")
        require(b"\x00" not in content and b"\x7fELF" not in content, "binary content: " + name)
        require(not any(re.search(marker, content) for marker in markers), "secret marker: " + name)


def pack(source, destination, repo):
    data = {}
    for name in ORIGINALS + ADDITIONS:
        path = source / name
        require(path.is_file() and not path.is_symlink(), "not a regular source file: " + name)
        data[name] = path.read_bytes()
    for name, expected in checksums((source / "SHA256SUMS").read_bytes()).items():
        require(digest((source / name).read_bytes()) == expected, "original checksum: " + name)
    for name, expected in PRERUN.items():
        require(digest((source / name).read_bytes()) == expected, "original pre-run hash: " + name)
    require((source / "candidate.test").read_bytes() ==
            (source / "candidate-committed.test").read_bytes(), "committed-source binary differs")
    data["PUBLIC_FILES.txt"] = ("\n".join(FILES) + "\n").encode()
    data["source-verification.json"] = (
        json.dumps(verify_source(data, repo), indent=2, sort_keys=True) + "\n"
    ).encode()
    verify_samples(data)
    verify_text(data)
    data["PUBLIC_SHA256SUMS"] = "".join(
        digest(content) + "  " + name + "\n" for name, content in sorted(data.items())
    ).encode()
    with io.BytesIO() as buffer:
        with tarfile.open(fileobj=buffer, mode="w", format=tarfile.USTAR_FORMAT) as archive:
            for name in FILES:
                member = tarfile.TarInfo(PREFIX + name)
                member.mode = 0o644
                member.size = len(data[name])
                archive.addfile(member, io.BytesIO(data[name]))
        destination.write_bytes(gzip.compress(buffer.getvalue(), compresslevel=9, mtime=0))


def audit(archive_path, repo):
    compressed = archive_path.read_bytes()
    require(compressed[:4] == b"\x1f\x8b\x08\x00" and compressed[4:8] == bytes(4),
            "gzip must have no optional fields and zero mtime")
    data = {}
    with tarfile.open(fileobj=io.BytesIO(gzip.decompress(compressed)), mode="r:") as archive:
        members = archive.getmembers()
        require([member.name for member in members] == [PREFIX + name for name in FILES],
                "archive differs from exact sorted allowlist")
        for member in members:
            require(member.isfile() and member.mode == 0o644 and member.uid == member.gid == 0
                    and member.mtime == 0 and member.uname == member.gname == ""
                    and not member.linkname and not member.pax_headers, "archive member metadata")
            data[member.name.removeprefix(PREFIX)] = archive.extractfile(member).read()
    require(data["PUBLIC_FILES.txt"].decode().splitlines() == list(FILES), "public allowlist")
    manifest = checksums(data["PUBLIC_SHA256SUMS"])
    require(set(manifest) == set(FILES) - {"PUBLIC_SHA256SUMS"}, "public checksum coverage")
    for name, expected in manifest.items():
        require(digest(data[name]) == expected, "public checksum: " + name)
    verify_text(data)
    source = verify_source(data, repo)
    require(source == json.loads(data["source-verification.json"]), "source verification record")
    return {
        "archive_sha256": digest(compressed), "archive_bytes": len(compressed),
        "public_regular_files": len(data), "public_checksums": len(manifest),
        "raw_observations": verify_samples(data), "bytes_per_op": 264, "allocs_per_op": 4,
        "source": source, "secret_marker_scan": "pass", "normalized_metadata": "pass",
        "excluded_binary_bytes_verified_by_public_audit": False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("pack", "audit"))
    parser.add_argument("archive", type=Path)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--source", type=Path)
    args = parser.parse_args()
    if args.mode == "pack":
        require(args.source is not None, "pack requires --source")
        pack(args.source, args.archive, args.repo)
    print(json.dumps(audit(args.archive, args.repo), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
