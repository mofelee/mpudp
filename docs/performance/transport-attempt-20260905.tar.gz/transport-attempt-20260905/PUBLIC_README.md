# Public Transport Attempt Evidence

This archive contains explicitly selected text records, source patches, a
benchmark parser and a reproducible archive/source audit. Compiled test binaries
are excluded; their pre-run SHA-256 values remain in `pre-run-SHA256SUMS` and the
original `README.md`. The original all-artifact `SHA256SUMS` is excluded because
it references those binaries. Verify `PUBLIC_SHA256SUMS` after extraction.

`README.md` is the unchanged producer record. Its temporary paths and host
metadata are public reconstruction context. `vet.log` is empty on success;
the test exit statuses are producer records, not captured test transcripts.
`remote-ref.txt` records the implementation branch before documentation commits.

Use the repository containing the pinned commits to audit this archive:

```sh
python3 public-evidence.py audit /path/to/transport-attempt-20260905.tar.gz --repo /path/to/mpudp
sha256sum -c PUBLIC_SHA256SUMS
python3 compare.py
```

The audit checks the exact allowlist, regular-file types, normalized metadata,
gzip metadata, all public checksums, text/credential markers, all 90 samples and
the committed source tree reconstructed by applying the preserved candidate
patch to the baseline in an isolated temporary Git index. It verifies the shared
fixture and timestamp fixture against the pinned candidate. It does not compile
or rerun benchmarks, verify excluded binary bytes, or establish network speed.

The producer separately checked all original artifact hashes and byte-identical
committed-source binaries before packing. The public audit verifies the recorded
binary hashes as metadata, without claiming the excluded binaries are present.
