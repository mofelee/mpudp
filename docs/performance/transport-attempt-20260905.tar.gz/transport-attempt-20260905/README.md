# Transport Actual-Attempt Time

Candidate worktree: `/tmp/mpudp-transport-attempt-time-20260905`.
Branch: `feat/22-transport-attempt-time`.
Baseline source: `5e19e44a6ea0d9e6a084129ebfe2075e4881ae00`.
Final candidate: `0ffd222f3bdbbfb81abe76ba1ce92e18a756220d`, also recorded in `candidate-commit.txt`. The branch is pushed; no PR was opened by this task.

`transport.SendWithAttempt(ctx, path, payload)` returns the time immediately before the captured transport connection's Write/WriteTo/WriteMsgUDPAddrPort call, after transport write-mutex acquisition, deadline setup and source-control validation. It returns zero for preflight rejection or unknown custom ReplyPaths. Short writes, native write errors and errors resetting the deadline retain the attempt time. This is a connection-call timestamp, not dispatch time or a guarantee of physical transmission.

The package helper recognizes exact native path types. A custom wrapper that overrides Send while inheriting a Carrier timing method still takes its own ordinary Send path and returns an unknown timestamp. No ReplyPath interface change is required. Ordinary Send passes nil timestamp storage and adds no clock read or allocation. The new timestamp does not enable diagnostics.

## Validation

- `go test ./internal/transport`: passed, exit 0; package elapsed 0.187 seconds.
- `go test -race ./...`: passed, exit 0, all 25 root-module packages.
- `go vet ./...`: passed, exit 0; `vet.log` is empty.
- `gofmt` and `git diff --check`: passed.
- Parent read-only code/test review and independent sibling review: no blocking findings.

New tests cover a held transport mutex and gated deadline setup, nil/canceled context, payload limit, deadline setup failure, captured generation rejection, unsupported source control, successful/empty/short/error/EMSGSIZE writes, deadline reset and write-error precedence, cancellation after a write begins, Close joining an active write, timestamp reset between calls, and custom adapter fallback. Existing native destination tests exercise the timed WithReplyStatistics path alongside ordinary Send for IPv4 alias destinations, IPv6 and dual-stack replies, preserving captured remote/source/OOB ownership.

## Preserved Inputs

`candidate.patch` is the complete candidate source/test change from the baseline, captured before running the measured binaries. `send_legacy_benchmark_test.go.txt` is byte-identical to the fixture in both baseline and candidate worktrees. The same patch is checked again against the committed candidate before delivery.

`pre-run-SHA256SUMS` was written before any benchmark invocation and revalidated immediately after all runs. It covers source patch, shared fixture, and both compiled executables. Initial hashes:

| Artifact | SHA-256 |
| --- | --- |
| candidate.patch | 957b2c37ea2d464e77f841203afd84763cd9be56dd26432c64fcf1a60eed191b |
| shared legacy fixture | 12174cf15cce5f779bee5320b7e929a0cface596a86f65d3ba91137a4286a336 |
| baseline.test | 3657ada5f86e9d488a38fbb3ecdeff2c064e669e2f5c0e3ffe313617884fc818 |
| candidate.test | edf12d44d841a22e89507a5f7f173d33e0556fffd0985c3fd28e584f93bd1d30 |
| candidate timestamp fixture | 24ed51b1fccef5179f293d2b5d2a3f1725343dae4fd46b69a954e8fad840d8eb |

The source patch was captured after compilation; its content was unchanged through compilation, the pre-run hash capture, and the runs. It is an explicit source snapshot, not a claim that a pre-commit executable embedded the eventual commit ID. Test executable build metadata has no embedded VCS revision. The committed-source rebuild `candidate-committed.test` is byte-identical to the measured candidate executable, and `candidate-committed.patch` is byte-identical to the pre-run source snapshot.

## Measurement

Native Linux/amd64, Go 1.26.4, Intel Xeon E3-1245 v5. `go-env.json`, `lscpu.json`, `kernel.txt` and `candidate-buildinfo.txt` preserve the environment. Process affinity was CPUs 0-5; each timed process was pinned to CPU 2 with GOMAXPROCS=1. `timing-start.txt` and `timing-end.txt` record the isolated window. Parent and sibling tests/builds/archive processing were held during it.

The fixture uses a deterministic connection with a 1200-byte packet and context.Background. It isolates transport locking, cancellation setup and diagnostics without UDP syscalls, network load, fresh per-send caller timeout contexts, or retained fake packet copies. Reported ns/op is benchmark elapsed time per operation, not a sampled CPU profile or product throughput. The fixture's MB/s field is therefore not a network bandwidth result.

The binaries were compiled once, then run sequentially with:

```sh
env GOMAXPROCS=1 taskset -c 2 ./baseline.test -test.run '^$' -test.bench '^BenchmarkTransportSendLegacy$' -test.benchtime=200ms -test.count=5 -test.cpu=1
env GOMAXPROCS=1 taskset -c 2 ./candidate.test -test.run '^$' -test.bench '^BenchmarkTransportSendLegacy$' -test.benchtime=200ms -test.count=5 -test.cpu=1
env GOMAXPROCS=1 taskset -c 2 ./candidate.test -test.run '^$' -test.bench '^BenchmarkTransportSendAttempt$' -test.benchtime=200ms -test.count=5 -test.cpu=1
```

Exact stdout/stderr is retained in `baseline.log`, `candidate-legacy.log` and `candidate-attempt.log`; all end in PASS and exited 0. `compare.py` produces `comparison.json` with all five samples per case and no discarded values.

| Path | Diagnostics | Baseline Send median ns | Candidate Send median ns | Timed helper median ns |
| --- | --- | ---: | ---: | ---: |
| Carrier | off | 706.5 | 695.8 | 783.7 |
| captured Carrier | off | 713.4 | 714.3 | 795.2 |
| listener | off | 801.2 | 813.7 | 892.4 |
| Carrier | on | 2193.0 | 970.0 | 1189.0 |
| captured Carrier | on | 956.8 | 966.9 | 1037.0 |
| listener | on | 1079.0 | 1097.0 | 1164.0 |

Every one of the 90 samples reports 264 B/op and 4 allocs/op. The timestamp path adds no allocation. Diagnostics-off timestamp overhead relative to candidate Send is 87.9 ns for Carrier, 80.9 ns for captured Carrier and 78.7 ns for listener. Ordinary Send diagnostics-off median changes are -1.5%, +0.1%, and +1.6% respectively; these small differences are descriptive, not statistical performance claims.

The baseline Carrier diagnostics-on series spans 1028-3000 ns/op and is visibly noisy. Its apparent improvement is not attributed to this change, and no sample was removed or repaired. This short local fixture comparison does not establish a network throughput uplift. The requested timestamp is a prerequisite for future worker pacing; no workers or pacing policy are changed here.
