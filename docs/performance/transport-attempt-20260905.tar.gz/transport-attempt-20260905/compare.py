#!/usr/bin/env python3
"""Summarize the preserved transport benchmark logs without discarding samples."""

import json
from pathlib import Path
import statistics


def read(path):
    lines = path.read_text().splitlines()
    if not lines or lines[-1] != "PASS":
        raise ValueError(f"benchmark did not pass: {path}")
    cases = {}
    for line in lines:
        if not line.startswith("Benchmark"):
            continue
        fields = line.split()
        if len(fields) != 10 or fields[3::2] != ["ns/op", "MB/s", "B/op", "allocs/op"]:
            raise ValueError(f"invalid benchmark line: {path}")
        name = fields[0].split("/", 1)[1]
        cases.setdefault(name, []).append({
            "iterations": int(fields[1]), "ns_per_op": float(fields[2]),
            "bytes_per_op": int(fields[6]), "allocs_per_op": int(fields[8]),
        })
    if len(cases) != 6 or any(len(rows) != 5 for rows in cases.values()):
        raise ValueError(f"unexpected benchmark cases or sample counts: {path}")
    result = {}
    for name, rows in cases.items():
        values = [row["ns_per_op"] for row in rows]
        result[name] = {
            "samples": rows, "median_ns_per_op": statistics.median(values),
            "min_ns_per_op": min(values), "max_ns_per_op": max(values),
            "bytes_per_op_values": sorted({row["bytes_per_op"] for row in rows}),
            "allocs_per_op_values": sorted({row["allocs_per_op"] for row in rows}),
        }
    return result


if __name__ == "__main__":
    print(json.dumps({name: read(Path(path)) for name, path in (
        ("baseline_send", "baseline.log"),
        ("candidate_send", "candidate-legacy.log"),
        ("candidate_send_with_attempt", "candidate-attempt.log"),
    )}, indent=2, allow_nan=False))
