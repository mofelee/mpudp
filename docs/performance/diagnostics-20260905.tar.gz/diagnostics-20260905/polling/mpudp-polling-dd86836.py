#!/usr/bin/env python3
import concurrent.futures
import datetime
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

URI = "qemu+ssh://ks/system"
SOURCE_SHA = "dd868367148a3eeaa071acfade3f3966ecd5a913"
DOMAINS = ["dbf-test-mpudp-client", "dbf-test-mpudp-server", *[f"dbf-test-mpudp-wan{i}" for i in range(1, 6)]]


def command(*args):
    value = subprocess.run(["virsh", "-c", URI, *args], capture_output=True, text=True, timeout=20)
    if value.returncode:
        raise RuntimeError("read-only virsh query failed")
    if len(value.stdout) > 1024 * 1024:
        raise ValueError("virsh evidence exceeds bound")
    return value.stdout


def mapping(domain):
    started = time.time_ns()
    uuid = command("domuuid", domain).strip()
    if not re.fullmatch(r"[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}", uuid):
        raise ValueError("invalid domain UUID")
    response = json.loads(command("qemu-monitor-command", domain, '{"execute":"query-cpus-fast"}'))
    cpus = response.get("return")
    if not isinstance(cpus, list) or len(cpus) != (2 if domain in DOMAINS[:2] else 1):
        raise ValueError("unexpected vCPU count")
    rows = []
    for cpu in cpus:
        path = cpu.get("qom-path")
        if not isinstance(path, str) or not re.fullmatch(r"/machine/[a-zA-Z0-9_/\[\].-]{1,128}", path):
            raise ValueError("unexpected QOM path")
        if any(type(cpu.get(key)) is not int or cpu[key] < 0 for key in ("cpu-index", "thread-id")):
            raise ValueError("invalid vCPU mapping")
        rows.append({"cpu_index": cpu["cpu-index"], "host_tid": cpu["thread-id"], "qom_path": path})
    return {"domain": domain, "uuid": uuid, "started_unix_ns": started,
            "finished_unix_ns": time.time_ns(), "vcpus": sorted(rows, key=lambda row: row["cpu_index"])}


def snapshot(phase):
    started = time.time_ns()
    mono = time.monotonic_ns()
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        mappings = list(executor.map(mapping, DOMAINS))
    query_started = time.time_ns()
    query_mono = time.monotonic_ns()
    raw = command("domstats", *DOMAINS, "--cpu-total", "--vcpu")
    query_finished, query_end_mono = time.time_ns(), time.monotonic_ns()
    counters, current = {}, None
    for line in raw.splitlines():
        if not line.strip():
            continue
        if line.startswith("Domain: '") and line.endswith("'"):
            current = line[len("Domain: '"):-1]
            if current not in DOMAINS or current in counters:
                raise ValueError("unexpected domain statistics")
            counters[current] = {}
            continue
        key, separator, value = line.strip().partition("=")
        if current is None or not separator or not re.fullmatch(r"(?:cpu|vcpu)\.[a-zA-Z0-9_.]{1,96}", key):
            raise ValueError("unexpected statistics field")
        if value in ("yes", "no"):
            parsed = value == "yes"
        elif re.fullmatch(r"[0-9]{1,20}", value):
            parsed = int(value)
        else:
            raise ValueError("statistics field is not bounded numeric metadata")
        counters[current][key] = parsed
    if set(counters) != set(DOMAINS) or sum(map(len, counters.values())) > 2048:
        raise ValueError("incomplete or excessive domain statistics")
    for row in mappings:
        values = counters[row["domain"]]
        required = ["cpu.time", "cpu.user", "cpu.system", "cpu.haltpoll.success.time", "cpu.haltpoll.fail.time"]
        for cpu in row["vcpus"]:
            required.extend(f"vcpu.{cpu['cpu_index']}.{field}" for field in
                            ("time", "halt_poll_success_ns.sum", "halt_poll_fail_ns.sum", "halt_wait_ns.sum",
                             "halt_attempted_poll.sum", "halt_successful_poll.sum"))
        if any(type(values.get(key)) is not int for key in required):
            raise ValueError("required polling or CPU statistics are missing")
        row["counters"] = values
    return {"schema": 1, "kind": "owned-vm-halt-poll-snapshot", "phase": phase, "source_sha": SOURCE_SHA,
            "captured_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "started_unix_ns": started, "finished_unix_ns": time.time_ns(),
            "started_monotonic_ns": mono, "finished_monotonic_ns": time.monotonic_ns(),
            "domstats_started_unix_ns": query_started, "domstats_finished_unix_ns": query_finished,
            "domstats_started_monotonic_ns": query_mono, "domstats_finished_monotonic_ns": query_end_mono,
            "domains": mappings, "configuration_changed": False, "workload_started": False}


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in ("before", "after"):
        raise SystemExit("expected before or after")
    phase = sys.argv[1]
    result = snapshot(phase)
    path = Path(f"/tmp/mpudp-polling-dd86836-{phase}.json")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"phase": phase, "output": str(path), "domains": len(result["domains"]),
                      "vcpus": sum(len(row["vcpus"]) for row in result["domains"]),
                      "domstats_query_ms": (result["domstats_finished_monotonic_ns"] - result["domstats_started_monotonic_ns"]) / 1e6}))
