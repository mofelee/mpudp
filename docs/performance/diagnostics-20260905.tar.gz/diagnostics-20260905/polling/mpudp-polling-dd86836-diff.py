#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path

PREFIX = Path("/tmp/mpudp-polling-dd86836")
before_path = Path(str(PREFIX) + "-before.json")
after_path = Path(str(PREFIX) + "-after.json")
case_path = Path("/tmp/mpudp-capacity-polling-dd86836/tcp-5path-upload-r1/summary.json")
before = json.loads(before_path.read_text())
after = json.loads(after_path.read_text())
case = json.loads(case_path.read_text())

assert before["source_sha"] == after["source_sha"]
assert before["phase"] == "before" and after["phase"] == "after"
old_domains = {row["domain"]: row for row in before["domains"]}
assert set(old_domains) == {row["domain"] for row in after["domains"]}
lower = after["domstats_started_monotonic_ns"] - before["domstats_finished_monotonic_ns"]
upper = after["domstats_finished_monotonic_ns"] - before["domstats_started_monotonic_ns"]
elapsed_ns = (lower + upper) / 2
assert lower > 0
rows = []
fields = ("time", "delay", "halt_poll_success_ns.sum", "halt_poll_fail_ns.sum", "halt_wait_ns.sum",
          "halt_attempted_poll.sum", "halt_successful_poll.sum", "halt_poll_invalid.sum",
          "halt_exits.sum", "halt_wakeup.sum", "exits.sum", "preemption_reported.sum", "preemption_other.sum")
for row in after["domains"]:
    old = old_domains[row["domain"]]
    assert old["uuid"] == row["uuid"] and old["vcpus"] == row["vcpus"]
    previous, current = old["counters"], row["counters"]
    keys = ("cpu.time", "cpu.user", "cpu.system", "cpu.haltpoll.success.time", "cpu.haltpoll.fail.time")
    delta = {key: current[key] - previous[key] for key in keys}
    vcpus = []
    for cpu in row["vcpus"]:
        prefix = f"vcpu.{cpu['cpu_index']}."
        values = {field: current[prefix + field] - previous[prefix + field] for field in fields}
        assert all(value >= 0 for value in values.values())
        vcpus.append({"cpu_index": cpu["cpu_index"], "host_tid": cpu["host_tid"], "delta": values})
    assert all(value >= 0 for value in delta.values())
    poll_ns = delta["cpu.haltpoll.success.time"] + delta["cpu.haltpoll.fail.time"]
    assert poll_ns == sum(cpu["delta"]["halt_poll_success_ns.sum"] + cpu["delta"]["halt_poll_fail_ns.sum"] for cpu in vcpus)
    rows.append({"domain": row["domain"], "uuid_unchanged": True, "vcpu_mapping_unchanged": True,
                 "delta": delta, "vcpus": vcpus, "poll_elapsed_ns": poll_ns,
                 "poll_elapsed_to_domain_cpu_percent": poll_ns * 100 / delta["cpu.time"] if delta["cpu.time"] else None,
                 "poll_elapsed_equivalent_cores": poll_ns / elapsed_ns})

def aggregate(items):
    cpu_ns = sum(row["delta"]["cpu.time"] for row in items)
    poll_ns = sum(row["poll_elapsed_ns"] for row in items)
    return {"domain_cpu_ns": cpu_ns,
            "vcpu_cpu_ns": sum(cpu["delta"]["time"] for row in items for cpu in row["vcpus"]),
            "poll_success_ns": sum(row["delta"]["cpu.haltpoll.success.time"] for row in items),
            "poll_fail_ns": sum(row["delta"]["cpu.haltpoll.fail.time"] for row in items),
            "poll_elapsed_ns": poll_ns, "poll_elapsed_to_domain_cpu_percent": poll_ns * 100 / cpu_ns,
            "poll_elapsed_equivalent_cores": poll_ns / elapsed_ns}

result = {"schema": 1, "kind": "owned-vm-halt-poll-delta", "source_sha": before["source_sha"],
          "before_captured_utc": before["captured_utc"], "after_captured_utc": after["captured_utc"],
          "input_sha256": {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in (before_path, after_path, case_path)},
          "domstats_midpoint_elapsed_ns": elapsed_ns,
          "domstats_elapsed_lower_bound_ns": lower, "domstats_elapsed_upper_bound_ns": upper,
          "domains": rows, "all_owned_domains": aggregate(rows),
          "routers": aggregate([row for row in rows if "-wan" in row["domain"]]),
          "native_case": {"aggregate_receiver_mbit_s": case["aggregate_receiver_mbit_s"],
                          "receiver_seconds_by_path": [row["seconds"] for row in case["paths"]],
                          "client_command_first_started_unix_ns": min(row["started_unix_ns"] for row in case["paths"]),
                          "client_command_last_finished_unix_ns": max(row["finished_unix_ns"] for row in case["paths"]),
                          "steady_hypervisor_headroom": case["hypervisor"]},
          "limitations": ["snapshot_span_includes_setup_warmup_load_and_idle",
                          "poll_elapsed_ns_is_kernel_elapsed_time_not_exact_scheduled_cpu_time",
                          "not_a_30_second_steady_state_poll_cpu_percentage",
                          "domain_cpu_denominator_covers_only_owned_domains_not_all_host_activity",
                          "snapshots_are_not_atomic_across_domains"],
          "configuration_changed": False, "product_acceptance": False}
path = Path(str(PREFIX) + "-delta.json")
fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps({"output": str(path), "all_owned_domains": result["all_owned_domains"], "routers": result["routers"]}))
