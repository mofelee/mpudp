# Aligned transport timing: 5e19e44

Source: `5e19e44a6ea0d9e6a084129ebfe2075e4881ae00`.
Binary SHA-256: `4fb8daa691211be40a5d7407ca89d0c7034e0f1d1f4f264c0638362da6d3a272`.
Both archives use this same source and binary.

- Diagnostics off: `/tmp/mpudp-alloc-diagnostics-5e19e44`.
- Diagnostics on: `/tmp/mpudp-alloc-timing-5e19e44`.
- Reader: `/tmp/mpudp-path-timing-reader-20260905.py`.
- Exact on results: `/tmp/mpudp-path-timing-on-20260905.json`.
- Exact off results: `/tmp/mpudp-path-timing-off-20260905.json` (also contains the two v2 download controls).

The reader revalidates the completion/identity contract and checksums of the inputs it reads through `report-probe.py`. This is not an all-members archive or secret audit. It uses live per-second sample boundary deltas, not final lifetime summaries. Both upload profiles have 19 client and 18 server samples; every diagnostics-on sample has nonzero timing counts on every path. Adjacent samples have no counter regressions or changed configured counter-slot identities. Those names can aggregate sockets and persist across rebuilds/Session churn; a stable name is not proof of an unchanged underlying socket generation. All sampled count/bucket totals match in these four upload cases; the reader nevertheless retains mismatches if present.

## Measurement Windows

Every row selects complete receiver buckets 1 through 15. Each side's rates use its own actual elapsed interval. The JSON retains precise timestamps. The boundary skew is measured timestamp separation, not a measured clock offset.

| Profile | Diagnostics | Sender seconds | Receiver seconds | Sender/receiver overlap seconds | Maximum boundary skew seconds | Receiver goodput Mbps |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| v2 | off | 14.999932051 | 14.999592066 | 14.826689959 | 0.173242092 | 45.401515 |
| v2 | on | 14.995902061 | 14.994965076 | 14.820842028 | 0.175060034 | 46.074624 |
| v2-aggregation | off | 15.000097036 | 15.000004053 | 14.827355146 | 0.172741890 | 97.377451 |
| v2-aggregation | on | 15.000770807 | 14.997338057 | 14.824820995 | 0.175949812 | 99.222699 |

This is one off/on observation per profile. The slightly higher on-run goodput does not establish negative instrumentation overhead, statistical significance, or a general throughput change. There is no interpolation or overlap rescaling. Sender/receiver counters must not be subtracted as packet-loss proof because their boundaries differ.

## Sender Paths

Bytes below are UDP payload bytes. Every sender datagram in these intervals has 1,200 payload bytes. Errors are zero for every sender path and both receiver listener sockets.

| Profile | Diagnostics | Path | Sent packets | Sent payload bytes | Packets/s | Payload Mbps |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| v2 | off | carrier-0 | 62664 | 75196800 | 4177.619 | 40.105142 |
| v2 | off | carrier-1 | 62665 | 75198000 | 4177.686 | 40.105782 |
| v2 | off | carrier-2 | 62665 | 75198000 | 4177.686 | 40.105782 |
| v2 | off | carrier-3 | 62665 | 75198000 | 4177.686 | 40.105782 |
| v2 | off | carrier-4 | 62665 | 75198000 | 4177.686 | 40.105782 |
| v2 | on | carrier-0 | 63664 | 76396800 | 4245.426 | 40.756094 |
| v2 | on | carrier-1 | 63664 | 76396800 | 4245.426 | 40.756094 |
| v2 | on | carrier-2 | 63665 | 76398000 | 4245.493 | 40.756735 |
| v2 | on | carrier-3 | 63664 | 76396800 | 4245.426 | 40.756094 |
| v2 | on | carrier-4 | 63664 | 76396800 | 4245.426 | 40.756094 |
| v2-aggregation | off | carrier-0 | 61969 | 74362800 | 4131.240 | 39.659903 |
| v2-aggregation | off | carrier-1 | 61969 | 74362800 | 4131.240 | 39.659903 |
| v2-aggregation | off | carrier-2 | 61970 | 74364000 | 4131.307 | 39.660543 |
| v2-aggregation | off | carrier-3 | 61969 | 74362800 | 4131.240 | 39.659903 |
| v2-aggregation | off | carrier-4 | 61969 | 74362800 | 4131.240 | 39.659903 |
| v2-aggregation | on | carrier-0 | 62363 | 74835600 | 4157.320 | 39.910269 |
| v2-aggregation | on | carrier-1 | 62364 | 74836800 | 4157.386 | 39.910909 |
| v2-aggregation | on | carrier-2 | 62363 | 74835600 | 4157.320 | 39.910269 |
| v2-aggregation | on | carrier-3 | 62363 | 74835600 | 4157.320 | 39.910269 |
| v2-aggregation | on | carrier-4 | 62363 | 74835600 | 4157.320 | 39.910269 |

## Sender Timing With Diagnostics On

Times below are microseconds. SocketWrite count equals sent packets, and WriteQueue count equals SocketWrite count, for every row in these selected intervals. All count/bucket deltas match. P50/P95/P99 are bounds from 24 non-cumulative power-of-two buckets, not exact quantiles.

| Profile | Path | SocketWrite observations | SocketWrite mean us | P50 us | P95 us | P99 us | WriteQueue mean us | WriteQueue P99 us |
| --- | --- | ---: | ---: | --- | --- | --- | ---: | --- |
| v2 | carrier-0 | 63664 | 17.870 | (8,16] | (32,64] | (64,128] | 0.108 | [0,1] |
| v2 | carrier-1 | 63664 | 22.612 | (8,16] | (32,64] | (128,256] | 0.102 | [0,1] |
| v2 | carrier-2 | 63665 | 19.390 | (8,16] | (32,64] | (64,128] | 0.103 | [0,1] |
| v2 | carrier-3 | 63664 | 18.938 | (8,16] | (32,64] | (64,128] | 0.118 | [0,1] |
| v2 | carrier-4 | 63664 | 20.525 | (8,16] | (32,64] | (64,128] | 0.104 | [0,1] |
| v2-aggregation | carrier-0 | 62363 | 19.981 | (8,16] | (32,64] | (64,128] | 0.113 | [0,1] |
| v2-aggregation | carrier-1 | 62364 | 17.074 | (8,16] | (32,64] | (64,128] | 0.108 | [0,1] |
| v2-aggregation | carrier-2 | 62363 | 20.905 | (8,16] | (32,64] | (128,256] | 0.108 | [0,1] |
| v2-aggregation | carrier-3 | 62363 | 17.727 | (8,16] | (32,64] | (64,128] | 0.114 | [0,1] |
| v2-aggregation | carrier-4 | 62363 | 20.465 | (8,16] | (32,64] | (64,128] | 0.104 | [0,1] |

Diagnostics-off timing histograms are empty throughout. They provide no latency baseline and must not be reported as zero latency.

Summed sender SocketWrite wall time is 6.324081244 seconds for v2 and 5.996372516 seconds for aggregation, over their respective approximately 15-second intervals. Summed transport WriteQueue time is 0.034042577 and 0.034117485 seconds. These are summed observation wall times, not CPU time or a measured owner-lock occupancy percentage. The sum of the five per-path socket-write means is approximately 99.34 us for v2 and 96.15 us for aggregation. That is a service-cost estimate for five sequential writes, not a measured group-duration distribution; per-path percentile values cannot be added into a group percentile.

## Receiver Shared Socket

The `listener` entry aggregates one socket. It is not five per-remote-path timings. In each upload interval it sends 378 reverse/control datagrams totaling 451536 UDP payload bytes; rates use the receiver durations above.

| Profile | Diagnostics | Listener sent packets/s | Payload Mbps | SocketWrite observations | SocketWrite mean us | SocketWrite P50 us | P95 us | P99 us | WriteQueue mean us |
| --- | --- | ---: | ---: | ---: | ---: | --- | --- | --- | ---: |
| v2 | off | 25.200685 | 0.240826 | 0 | unavailable | unavailable | unavailable | unavailable | unavailable |
| v2 | on | 25.208462 | 0.240900 | 378 | 63.901 | (32,64] | (128,256] | (512,1024] | 0.095 |
| v2-aggregation | off | 25.199993 | 0.240819 | 0 | unavailable | unavailable | unavailable | unavailable | unavailable |
| v2-aggregation | on | 25.204473 | 0.240862 | 378 | 68.096 | (32,64] | (128,256] | (512,1024] | 0.093 |

Listener WriteQueue P50/P95/P99 are all [0,1] us with diagnostics on. The exact JSON includes received packets/bytes and receive PPS as well as all histogram deltas.

## Interpretation And Limits

SocketWrite measures wall time around the socket write call, including returned write errors. It excludes time spent preparing transport state, setting or resetting deadlines, FEC work, v2 owner-lock wait, and pacing waits. WriteQueue measures only acquisition of the transport write mutex. It does not measure the v2 owner lock. Their observation sets can differ on early-error or cancellation paths, even though the selected counts happen to agree here.

The small transport write-lock wait does not clear the v2 owner lock of contention. Approximately 96-99 us of sequential socket service for five writes is already comparable to the roughly 98 us per-path pacing quantum at 100 Mbps, before other sender work. Together with the separately collected owner-lock contention profile, this supports investigating bounded send workers. It does not predict a throughput uplift or prove pacing-timer lateness. A group/emit wall-time measurement and owner-wait/timer-lateness measurement remain useful to distinguish the remaining costs.

`max_ns` is a lifetime maximum. The JSON preserves both boundary values and leaves the interval maximum unavailable. Counter, total, maximum and bucket fields are sampled independently; apparent agreement here does not change those semantics. Quantile ranks use the sum of bucket deltas. No payload counters are converted into exact physical-wire bytes or exact per-path loss.

Validation: synthetic tests covered the 24-bucket layout, first and overflow quantile bounds, counter regression rejection, boolean rejection, retained non-atomic count/bucket mismatch, unchanged lifetime maximum, and unavailable empty diagnostics-off histograms. Both archive readers completed successfully. Independent read-only review found no arithmetic/alignment/ownership blocker and its configured-counter-slot terminology correction was incorporated. No product files or schemas were changed, and this analysis generated no network traffic or load.
