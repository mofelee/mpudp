#!/usr/bin/env python3
"""Read aligned per-path timing deltas from a completed run-probe archive."""

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path


UPPER_NS = [1000 * 2**index for index in range(23)] + [None]
TIMINGS = ("socket_write", "write_queue")
SOCKET_COUNTERS = ("sent_packets", "sent_bytes", "send_errors", "received_packets",
                   "received_bytes", "receive_oversize_drops")


def nonnegative_integer(value, label):
    if type(value) is not int or value < 0:
        raise ValueError(f"invalid nonnegative integer: {label}")
    return value


def counter_delta(before, after, key):
    a = nonnegative_integer(before.get(key), key)
    b = nonnegative_integer(after.get(key), key)
    if b < a:
        raise ValueError(f"regressing counter: {key}")
    return b - a


def histogram(value):
    if not isinstance(value, dict):
        raise ValueError("missing transport latency histogram")
    for key in ("count", "total_ns", "max_ns"):
        nonnegative_integer(value.get(key), key)
    buckets = value.get("buckets")
    if not isinstance(buckets, list) or len(buckets) != len(UPPER_NS):
        raise ValueError("transport latency histogram must contain 24 buckets")
    for count in buckets:
        nonnegative_integer(count, "bucket")
    return value


def quantile_bounds(buckets, fraction):
    count = sum(buckets)
    if count == 0:
        return None
    rank, accumulated = math.ceil(count * fraction), 0
    for index, value in enumerate(buckets):
        accumulated += value
        if accumulated >= rank:
            return {"rank": rank, "bucket_index": index,
                    "lower_ns": 0 if index == 0 else UPPER_NS[index - 1],
                    "lower_inclusive": index == 0,
                    "upper_ns": UPPER_NS[index], "upper_inclusive": UPPER_NS[index] is not None}
    raise ValueError("histogram rank was not found")


def timing_delta(before, after, enabled):
    before, after = histogram(before), histogram(after)
    count = counter_delta(before, after, "count")
    total = counter_delta(before, after, "total_ns")
    counter_delta(before, after, "max_ns")
    buckets = [counter_delta({"bucket": a}, {"bucket": b}, "bucket")
               for a, b in zip(before["buckets"], after["buckets"])]
    bucket_count = sum(buckets)
    return {"diagnostics_enabled": enabled, "observations_available": bucket_count > 0,
            "count_delta": count, "total_ns_delta": total,
            "mean_ns_from_counter_deltas": total / count if count else None,
            "non_cumulative_bucket_deltas": buckets, "bucket_count_delta": bucket_count,
            "bucket_minus_count_delta": bucket_count - count,
            "counter_and_bucket_counts_match": count == bucket_count,
            "p50_bounds_ns": quantile_bounds(buckets, .50),
            "p95_bounds_ns": quantile_bounds(buckets, .95),
            "p99_bounds_ns": quantile_bounds(buckets, .99),
            "start_lifetime_max_ns": before["max_ns"], "end_lifetime_max_ns": after["max_ns"],
            "interval_max_ns": None}


def path_map(telemetry):
    if telemetry.get("mpudp_statistics_available") is not True:
        raise ValueError("MPUDP statistics unavailable at selected boundary")
    entries = telemetry["mpudp"]["paths"]
    result = {}
    for path in entries:
        name = path.get("path")
        if not isinstance(name, str) or not name or name in result:
            raise ValueError("invalid or duplicate configured counter-slot identity")
        result[name] = path
    return result


def side_timing(first, last, reporter):
    a, b = first["telemetry"], last["telemetry"]
    elapsed = reporter.runner.instant(b["at_utc"]) - reporter.runner.instant(a["at_utc"])
    if elapsed <= 0:
        raise ValueError("nonpositive sample interval")
    enabled = a["mpudp"].get("diagnostics_enabled")
    if type(enabled) is not bool or b["mpudp"].get("diagnostics_enabled") is not enabled:
        raise ValueError("diagnostics mode changed inside selected interval")
    before, after = path_map(a), path_map(b)
    if before.keys() != after.keys():
        raise ValueError("configured counter-slot identities changed inside selected interval")
    paths = []
    for name in before:
        change = {key: counter_delta(before[name], after[name], key) for key in SOCKET_COUNTERS}
        paths.append({"path": name, **change,
                      "sent_pps": change["sent_packets"] / elapsed,
                      "received_pps": change["received_packets"] / elapsed,
                      "sent_udp_payload_bytes_per_second": change["sent_bytes"] / elapsed,
                      "received_udp_payload_bytes_per_second": change["received_bytes"] / elapsed,
                      "sent_udp_payload_mbps": change["sent_bytes"] * 8 / elapsed / 1e6,
                      **{key: timing_delta(before[name].get(key), after[name].get(key), enabled)
                         for key in TIMINGS}})
    return {"start_utc": a["at_utc"], "end_utc": b["at_utc"], "elapsed_seconds": elapsed,
            "diagnostics_enabled": enabled, "paths": paths}


def analyze(directory, reporter_path, tolerance, profiles):
    spec = importlib.util.spec_from_file_location("path_timing_reporter", reporter_path)
    reporter = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reporter)
    validated = reporter.report(directory, tolerance)
    read = reporter.checked_reader(directory)
    cases = []
    for checked_case in validated["cases"]:
        case = checked_case["case"]
        if case["protocol"] != "mpudp" or case.get("mpudp_profile", "v1") not in profiles:
            continue
        workers = []
        for index, checked_worker in enumerate(checked_case["workers"]):
            rows = {side: read(f"{case['case_id']}/{side}-{index}.jsonl", jsonl=True)
                    for side in ("client", "server")}
            receiver_side = checked_worker["receiver_side"]
            sender_side = "client" if receiver_side == "server" else "server"
            receiver = reporter.runner.unique_record(rows[receiver_side], "summary")
            first, last, buckets = reporter.aligned_samples(rows[receiver_side], rows[sender_side], receiver, tolerance)
            receive = side_timing(first[0], last[0], reporter)
            send = side_timing(first[1], last[1], reporter)
            overlap_start = max(reporter.runner.instant(side["start_utc"]) for side in (receive, send))
            overlap_end = min(reporter.runner.instant(side["end_utc"]) for side in (receive, send))
            if overlap_end <= overlap_start:
                raise ValueError("sender and receiver sample windows do not overlap")
            workers.append({"worker_id": checked_worker["worker_id"], "receiver_side": receiver_side,
                            "first_receiver_bucket": buckets[0]["second"],
                            "last_receiver_bucket": buckets[-1]["second"], "bucket_seconds": len(buckets),
                            "receiver_verified_mbps": checked_worker["receiver_verified_mbps"],
                            "max_boundary_skew_seconds": checked_worker["max_boundary_skew_seconds"],
                            "sender_receiver_overlap_seconds": overlap_end - overlap_start,
                            "sender": send, "receiver": receive})
        cases.append({"case": case, "workers": workers})
    if not cases:
        raise ValueError("no requested MPUDP profile cases found")
    return {"source_sha": validated["source_sha"], "binary_sha256": validated["binary_sha256"],
            "artifact_directory": str(directory.resolve()), "input_checksums_revalidated": True,
            "reader_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "reporter_sha256": hashlib.sha256(reporter_path.read_bytes()).hexdigest(),
            "probe_runner_sha256": hashlib.sha256(reporter_path.with_name("run-probe.py").read_bytes()).hexdigest(),
            "alignment_tolerance_seconds": tolerance,
            "latency_histogram": {"unit": "nanoseconds", "non_cumulative": True,
                                  "inclusive_upper_bounds_ns": UPPER_NS, "null_upper_means_overflow": True},
            "interpretation": [
                "Checksum validation covers files read by report() and this reader, not every public archive member.",
                "Rates use each side's actual selected sample interval; no interpolation or overlap rescaling.",
                "Receiver goodput uses complete receiver buckets between aligned boundaries.",
                "Counter and histogram fields are sampled independently; bucket/count mismatch is reported, not repaired.",
                "Quantiles are bounds from bucket deltas, not exact percentiles; an empty histogram is unavailable.",
                "max_ns is a lifetime maximum and cannot be subtracted into an interval maximum.",
                "SocketWrite measures only socket write-call wall time, including returned write errors.",
                "WriteQueue measures transport write-lock wait, excluding v2 owner-lock wait and pacing delay.",
                "Socket timing and queue timing observation sets can differ across cancellation or early-error paths.",
                "sent_bytes and received_bytes count UDP payload bytes; no IP/UDP headers are added.",
                "Path names identify configured counter slots, which may aggregate multiple sockets and persist across rebuilds or Session churn.",
                "The listener counter slot aggregates listener socket writes, not a per-remote-path breakdown.",
                "Diagnostics-off zero histograms do not establish zero send latency.",
                "No owner-lock or pacing-timer lateness can be inferred from these distributions.",
            ], "cases": cases}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--reporter", type=Path, default=Path("/root/mpudp/scripts/perf/report-probe.py"))
    parser.add_argument("--alignment-tolerance-seconds", type=float, default=.25)
    parser.add_argument("--profile", action="append", choices=("v1", "v2", "v2-aggregation"))
    args = parser.parse_args()
    print(json.dumps(analyze(args.directory, args.reporter, args.alignment_tolerance_seconds,
                             args.profile or ["v2", "v2-aggregation"]), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
