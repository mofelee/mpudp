# Negotiated Path Storage Benchmark Evidence

Base source: `ae7cddf3c12e47af502f1e71461702110bbaf303`.
Verified implementation commit: `28f786b6abb52c8ed4cff94c5b2ea539be279faf`.

Both runs use the identical `fixture.patch`, which constructs controllers through
`New` using negotiation profiles and prepaid leases, then completes path joins
and fixed-budget publication. The client/server advertised path pairs are 5/5,
5/256, 256/5 and 256/256. Group counts 0 and 1057 use synthetic pending-group
metadata for deadline lookup, matching the earlier deadline benchmark pattern;
this is not a transport or storage-admission throughput measurement.

The before run uses the base production source. The after run additionally
applies `production.patch`. Full copies of the two changed fixture files are
included. Both commands completed with PASS, sequentially on the same machine:

```sh
go test ./internal/sessionv2 -run '^$' -bench '^BenchmarkNegotiatedPathCapacity$' -benchmem -benchtime=100ms -count=3
```

For client 5 / server 256, server medians are:

| Operation | Before ns/op | After ns/op |
| --- | ---: | ---: |
| NextDeadline, 0 groups | 28796 | 675.1 |
| NextDeadline, 1057 groups | 30303 | 722.6 |
| driveControl | 3096 | 205.9 |
| expireControl | 21660 | 445.2 |

All shown cases allocate zero bytes and zero objects per operation. These are
three short local repetitions, not confidence intervals or a network acceptance
result. Symmetric 256/256 negotiation still permits and stores all 256 paths;
this change removes only path records outside the authenticated negotiated bound.
Local-offer prepaid credit is unchanged in both runs.

Private CPU profiles are not included. The observed uploaded v2 and aggregation
profiles attributed 47.41% and 45.40% cumulative CPU respectively to NextDeadline,
with most line-level cost in the per-path reply/old-route loops. A new network run
and profile are still required to establish the resulting end-to-end behavior.
