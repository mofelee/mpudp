# Directional Authenticator Benchmark Replay

Base commit: `5e19e44a6ea0d9e6a084129ebfe2075e4881ae00`.

Baseline worktree: `/tmp/mpudp-v2-directional-auth-baseline-20260905`.
Optimized worktree: `/tmp/mpudp-v2-directional-authenticator-20260905`.

The baseline contains the base commit plus only the new stateless envelope
benchmark from `mpudp-auth-baseline-fixture-20260905.patch`. The existing
`BenchmarkFECBundleAppend` fixture is unchanged from the base commit. The
optimized tree contains the base commit plus `mpudp-auth-production-20260905.patch`
and `mpudp-auth-fixtures-20260905.patch`. Exact patch hashes are recorded in
`mpudp-auth-patch-sha256-20260905.txt`.

Both executables were built before timing:

```sh
# Baseline worktree
go test -c -o /tmp/mpudp-auth-baseline-20260905.test ./internal/wirev2
# Optimized worktree
go test -c -o /tmp/mpudp-auth-optimized-20260905.test ./internal/wirev2
```

Executable and stateless-envelope fixture hashes were captured before timing in
`mpudp-auth-benchmark-sha256-20260905.txt`. Both executables identify Go 1.26.4,
linux/amd64, CGO_ENABLED=1, GOAMD64=v1. Complete `go version -m` output is in
`mpudp-auth-toolchain-20260905.txt`; `go env` output is in
`mpudp-auth-go-environment-20260905.json`. GOEXPERIMENT is empty, so these are native
Go crypto measurements, not BoringCrypto measurements. GOMAXPROCS was unset in
the environment; every benchmark reports runtime GOMAXPROCS=6 through its `-6`
suffix. The environment observation is in `mpudp-auth-gomaxprocs-20260905.txt`.

The following commands ran sequentially, with no concurrent tests, builds, or
network measurements. The exclusive timing window was coordinated with
benchmark_probe after root released its diagnostics runs:

```sh
/tmp/mpudp-auth-baseline-20260905.test -test.run '^$' -test.bench '^(BenchmarkFECBundleAppend|BenchmarkEnvelopeAuthenticate)$' -test.benchtime=200ms -test.count=5 | tee /tmp/mpudp-auth-stateless-baseline-20260905.txt
/tmp/mpudp-auth-optimized-20260905.test -test.run '^$' -test.bench '^(BenchmarkFECBundleAppend|BenchmarkEnvelopeAuthenticate)$' -test.benchtime=200ms -test.count=5 | tee /tmp/mpudp-auth-stateless-refactored-20260905.txt
/tmp/mpudp-auth-optimized-20260905.test -test.run '^$' -test.bench '^BenchmarkDirectionalAuthenticator' -test.benchtime=200ms -test.count=5 | tee /tmp/mpudp-auth-directional-warmed-20260905.txt
```

All three executable runs printed PASS. The original and refactored stateless
paths retain identical allocation counts in all measured shapes. Observed bytes
also match except for maximum-size reused_prefix_0: the original records
66105 B/op in three runs and 66104 B/op in two, while the refactored path records
66104 B/op in all five runs.
For UDP1200, nil-destination FEC encoding is 1848 B/op and 9 allocs/op in both
stateless trees, versus 1280 B/op and 1 alloc/op with a warmed directional owner.
Envelope authentication is 544 B/op and 7 allocs/op in both stateless trees,
versus 0 B/op and 0 allocs/op with a warmed owner. Cold owner construction and
Close cost 848 B/op and 9 allocs/op in the measured native implementation.

UDP1200 median encoding times are 5628 ns/op (original), 5201 ns/op (refactored
stateless), and 4539 ns/op (warmed owner). Median authentication times are
5029, 5110, and 3697 ns/op respectively. Timings have visible run-to-run noise;
these are local microbenchmarks, not network-throughput or alternate-provider
claims. The prepaid 4096 bytes per direction is a separate retained-state
allowance, not an assertion about process RSS or opaque native-provider memory.
