# Directional Authenticator Benchmark Evidence

Base: `5e19e44a6ea0d9e6a084129ebfe2075e4881ae00`.
Optimized source: `f6bc4322dfe7b22f5cc29cf07df737ebf829e032`.

This archive preserves 12 original producer files and 200 captured observations:
15 stateless cases before/refactored and 10 directional/construction cases,
each repeated five times. No benchmark, network run or executable rebuild was
performed by the auditor. Executable binaries and private profiles are excluded.

## Results

At UDP1200, original and refactored stateless nil-destination FEC encoding both
record 1848 B/op and 9 allocs/op. The warmed directional owner records 1280 B/op
and 1 alloc/op. Stateless authentication records 544 B/op and 7 allocs/op; warmed
authentication records 0 B/op and 0 allocs/op. Cold construction plus Close
records 848 B/op and 9 allocs/op, separately from warmed operation measurements.

UDP1200 median encoding is 5628 / 5201 / 4539 ns/op for original/refactored/warmed;
authentication is 5029 / 5110 / 3697 ns/op. These are short local measurements,
not a throughput prediction or an estimate with confidence intervals.

All stateless object counts match. Allocation bytes also match except that
the original maximum-size reused_prefix_0 case records 66105 B/op three times
and 66104 twice, while refactored records 66104 five times. The median is therefore
66105 versus 66104 for that case. The archive retains the raw observations,
medians and ranges instead of claiming literal equality for every sample.

## Reproduction And Provenance

`original/mpudp-auth-replay-20260905.md` records the exact build/run commands,
timing order, source folders and original evidence filenames. Apply its baseline
fixture patch to the base; the existing FEC bundle benchmark remains unchanged.
For the optimized build apply the production and full fixture patches to the
same base. `fixtures/` contains exact fixture sources for inspection. Both
source sets are independently reconstructed against the pinned commit.

Recorded executable SHA256 values were rechecked, and current read-only
`go version -m` output matches the captured executable metadata. Both are native
Go 1.26.4 Linux/amd64, CGO_ENABLED=1, GOAMD64=v1, with empty GOEXPERIMENT.
Recorded environment GOMAXPROCS is unset and all log suffixes identify runtime
GOMAXPROCS 6. The binaries are not published. Metadata contains no VCS source
attestation; association with source patches and command order remains
producer-recorded rather than independently proving a reproducible build.

The owner is serialized and prepaid 4096 bytes per direction. This is a standing
retained-state allowance, not RSS or an opaque-provider heap guarantee.
Native Go warm-state results do not establish BoringCrypto allocation behavior.
Native FIPS code was reviewed for storage layout, but this benchmark does not
claim an explicitly enabled FIPS-mode timing run. The warmed fixture uses valid
FEC bodies; stateless authentication uses an equal-length opaque envelope body.
Wire authentication benchmarks omit owner locks, transport and pacing work.

## Audit

All members are explicitly selected, scanned for known private markers, and
packaged with deterministic metadata. Verify `PUBLIC_SHA256SUMS` at the archive
root. Producer checksum files retain their original absolute capture paths;
`audit.json` records their verification and every original member digest.
`benchmark-summary.json` retains exact log line numbers and all observations.
Nothing from a private `.lab` tree, executable payload or profile is exported.
