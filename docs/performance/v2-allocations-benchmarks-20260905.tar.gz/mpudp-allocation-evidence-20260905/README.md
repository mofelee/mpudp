# Allocation Increment Benchmark Evidence

Common base: `28f786b6abb52c8ed4cff94c5b2ea539be279faf`.
Scalar completion source: `302a07ed6f8d48010bc0a7114780db0f1c365ee1`.
Single-buffer source: `192153a909f48eb195d7b804b30aad5ac15d700d`.
Combined delivery source: `5e19e44a6ea0d9e6a084129ebfe2075e4881ae00`.

These are captured isolated microbenchmarks, not a benchmark of the combined
delivery source or a network throughput prediction. No benchmark was rerun by
the auditor. Source patches and fixture files are reconstructed against the
pinned commits; all 180 raw observations remain in the included logs.

## Scalar Completion

The original six-file producer package is preserved under `completion/`,
including its README, checksum index, tests, production patch and raw log.
Apply `completion/production.patch` and `completion/fixture.patch` to the common
base. The benchmark compares Snapshot field extraction with Completion in one
executable, using the unchanged Snapshot implementation. Producer command:

```sh
go test ./internal/sessionv2 -run '^$' -bench '^BenchmarkCompletionPolling$' -benchmem -benchtime=200ms -count=5
```

Five-path Snapshot polling allocates 1808 B/op and 4 objects/op; Completion
allocates zero. These figures exclude owner locking, wakeups, cancellation,
closed-session handling and failure-frontier filtering. Pending groups are
synthetic metadata, not admitted shard storage or measured transport traffic.

## Single-Buffer Encoding

At the common base, install `single-buffer/fixture.patch`, which contains the
identical bundle append regression and benchmark files used in both timing
runs. Run the baseline command below, apply `single-buffer/production.patch`,
then run the optimized command. The production patch also preserves the
conservative two-packet credit reservation through an explanatory comment.

```sh
go test ./internal/wirev2 -run '^$' -bench '^BenchmarkFECBundleAppend$' -benchtime=200ms -count=5 | tee /tmp/mpudp-v2-single-buffer-baseline-20260905.txt
go test ./internal/wirev2 -run '^$' -bench '^BenchmarkFECBundleAppend$' -benchtime=200ms -count=5 | tee /tmp/mpudp-v2-single-buffer-optimized-20260905.txt
```

The fixture itself enables allocation reporting. At UDP1200, nil-destination
encoding decreases from 3000 to 1848 B/op and from 10 to 9 allocs/op. Median
timing is 5601 versus 5625 ns/op; no CPU speedup is established. Nonnil reused
destination allocations are unchanged. Shape labels name payload budgets;
the sixteen-record shape encodes 1388 bytes under its 1472-byte budget.
Allocation summary values are medians with observed ranges. The optimized
maximum-size nil case records 66105 B/op once and 66104 B/op four times;
the raw variation is retained rather than treated as a constant observation.

The producer confirms baseline contained only the two added, formatted test
files on the common base. It then applied the bundle encoder change and credit
comment before the optimized command. Both commands completed with PASS in a
coordinated sequential timing window before its full race/vet runs.

## Provenance And Limits

Logs contain goos, goarch, package, CPU model and benchmark concurrency suffix
6. Compiler version and temporary test executable hashes were not captured at
timing time. Commands, ordering and source association are producer-recorded;
the auditor verifies the captured patches match the named commits, not an
unrecorded executable identity. Current tool versions are not substituted for
missing timing provenance. Five 200ms repetitions are not confidence intervals.

The combined production patch applies both isolated changes to the common
base and matches the combined source. This confirms source integration only;
the archive contains no combined-build benchmark, profile or network run.

Every archive member is explicitly selected and checked for known private
markers; profiles, private configurations, keys and `.lab` are excluded. Verify
`PUBLIC_SHA256SUMS` at the archive root and the original `completion/SHA256SUMS`
from inside that subdirectory. `benchmark-summary.json` contains the parsed
observations and medians; `audit.json` records source reconstruction and hashes.
