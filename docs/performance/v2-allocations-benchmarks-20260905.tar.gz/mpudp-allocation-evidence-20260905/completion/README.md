# Scalar Completion Polling Evidence

Base source: `28f786b6abb52c8ed4cff94c5b2ea539be279faf`.
Verified implementation commit: `302a07ed6f8d48010bc0a7114780db0f1c365ee1`.

The benchmark compares the exact previous fence-poll operation, extracting
CompletedThrough/FailedFrom/SendError from Controller.Snapshot, with the new
Controller.Completion accessor in the same executable. Snapshot itself is
unchanged. It constructs real prepaid controllers, completes path negotiation,
and uses 1, 5 or 256 negotiated paths. Pending-group counts 0 and 1057 use
synthetic metadata for deadline reads, not live traffic or admission pressure.

To reproduce, apply production.patch to the base and place completion_bench_test.go
in internal/sessionv2. Existing fixtures from the base provide the constructor and
negotiation helpers. The successful command was:

```sh
go test ./internal/sessionv2 -run '^$' -bench '^BenchmarkCompletionPolling$' -benchmem -benchtime=200ms -count=5
```

Median results from five sequential repetitions:

| Paths | Pending groups | Snapshot ns/op | Completion ns/op | Snapshot B/op | Snapshot allocs/op |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 0 | 545.8 | 2.279 | 112 | 1 |
| 1 | 1057 | 562.3 | 1.687 | 112 | 1 |
| 5 | 0 | 1782 | 1.710 | 1808 | 4 |
| 5 | 1057 | 2007 | 1.868 | 1808 | 4 |
| 256 | 0 | 76048 | 1.794 | 65296 | 9 |
| 256 | 1057 | 89736 | 1.811 | 65296 | 9 |

Completion allocates zero bytes and objects in every case. These timings isolate
the poll operation; they are not an end-to-end fence-wait benchmark or a network
throughput prediction. Owner locking, wake notifications, cancellation, closed
session checks and failure-frontier filtering remain outside the accessor.

The included regression verifies nil/empty reads, successful and failed frontiers,
Close preservation, and absence of path-availability callbacks. Existing fence
integration tests cover cancellation, later failures and concurrent closure.
Focused tests, the full `go test -race ./...` suite, and `go vet ./...` passed.
Private profiles are not included.
